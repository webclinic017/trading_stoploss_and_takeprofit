
# Change Log
All notable changes to this project will be documented in this file.
 
## v1.0.1 - 9/12/2021

  Fix bug - change rolling percentage change of high to low to change per period to allow custom rolling
## v1.0.0 - 9/12/2021
 
  Intial release

